#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 [user@]host [flag]" >&2
  exit 1
fi

REMOTE="$1"
_default_flag='SK-CERT{fake}'
FLAG="${2:-${FLAG:-$_default_flag}}"
REMOTE_DIR="/opt/suricats"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ssh_ok()  { ssh "$REMOTE" "$1" || true; }
ssh_req() { ssh "$REMOTE" "$1"; }

echo "[*] Target   : $REMOTE"
echo "[*] Flag     : $FLAG"
echo "[*] RemoteDir: $REMOTE_DIR"
echo ""

echo "[1/7] Tearing down previous deployment..."
ssh_ok "docker rm -f suricata-flagtest"
ssh_ok "pkill -fx 'python3 /opt/suricats/flag_server.py'"
ssh_ok "iptables -D INPUT  -p tcp --dport 8585 -m mark ! --mark 1 -j NFQUEUE --queue-num 0"
ssh_ok "iptables -D OUTPUT -p tcp --sport 8585 -m mark ! --mark 1 -j NFQUEUE --queue-num 0"

echo "[2/7] Creating remote directories..."
ssh_req "mkdir -p ${REMOTE_DIR}/rules ${REMOTE_DIR}/logs"

echo "[3/7] Uploading files..."
scp "$SCRIPT_DIR/app/flag_server.py"         "$REMOTE:${REMOTE_DIR}/flag_server.py"
scp "$SCRIPT_DIR/suricata/suricata.yaml"     "$REMOTE:${REMOTE_DIR}/suricata.yaml"
scp "$SCRIPT_DIR/suricata/rules/local.rules" "$REMOTE:${REMOTE_DIR}/rules/local.rules"

echo "[4/7] Writing flag..."
ssh_req "printf '%s\n' '${FLAG}' > /flag && chmod 400 /flag"

echo "[5/7] Starting flag_server (port 8585)..."
ssh_req "nohup python3 ${REMOTE_DIR}/flag_server.py >${REMOTE_DIR}/flag_server.log 2>&1 &"
sleep 2
if ssh_req "ss -tlnp | grep -q 8585"; then
  echo "  OK: flag_server listening"
else
  echo "  ERROR: flag_server failed to start"
  ssh_ok "cat ${REMOTE_DIR}/flag_server.log"
  exit 1
fi


echo "[6/7] Starting Suricata 9.0.0-dev (jasonish/suricata:main-amd64)..."
ssh_ok "docker pull jasonish/suricata:main-amd64 2>&1 | tail -2"
ssh_req "docker run -d --name suricata-flagtest \
    --network host \
    --cap-add NET_ADMIN --cap-add NET_RAW --cap-add SYS_NICE \
    -v ${REMOTE_DIR}/suricata.yaml:/etc/suricata/suricata.yaml \
    -v ${REMOTE_DIR}/rules/local.rules:/etc/suricata/rules/local.rules \
    -v ${REMOTE_DIR}/logs:/var/log/suricata \
    jasonish/suricata:main-amd64 \
    -c /etc/suricata/suricata.yaml -q 0 --runmode workers"

echo "  Waiting for Suricata engine..."
for i in $(seq 1 20); do
  if ssh_req "docker logs suricata-flagtest 2>&1 | grep -q 'Engine started'"; then
    echo "  OK: Suricata engine started"
    break
  fi
  if [ "$i" -eq 20 ]; then
    echo "  ERROR: Suricata did not start in time"
    ssh_ok "docker logs suricata-flagtest 2>&1 | tail -10"
    exit 1
  fi
  sleep 1
done

echo "[7/7] Adding iptables NFQ rules (INPUT + OUTPUT, port 8585)"
ssh_req "iptables -I INPUT  -p tcp --dport 8585 -m mark ! --mark 1 -j NFQUEUE --queue-num 0"
ssh_req "iptables -I OUTPUT -p tcp --sport 8585 -m mark ! --mark 1 -j NFQUEUE --queue-num 0"
ssh_req "docker ps --filter name=suricata-flagtest --format '  {{.Names}}  {{.Status}}'"

echo ""
echo "[+] Deployment complete."
echo "    Connect    : nc ${REMOTE##*@} 8585"
echo "    Block test : echo give_me_the_flag | nc ${REMOTE##*@} 8585"
echo "    Suricata   : ssh ${REMOTE} \"docker exec suricata-flagtest tail -f /var/log/suricata/fast.log\""
