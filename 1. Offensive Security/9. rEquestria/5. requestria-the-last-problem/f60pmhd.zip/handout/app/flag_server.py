#!/usr/bin/env python3
import os
import socketserver

HOST = os.environ.get("FLAG_HOST", "0.0.0.0")
PORT = int(os.environ.get("FLAG_PORT", "8585"))
FLAG = open("/flag").read().strip()


SEP = ("+" + "=+" * 32 + "\n").encode()
BANNER = (
    SEP.decode()
    + "  rEQUESTRIA CHALLENGE SERVER --  CyberGame 2026 [BETA]\n"
    "  ** UNVERIFIED CHALLENGE -- internal testing only **\n"
    "  ** players are gonna be so angry when we drop unverified chall again :DDDD **\n"
    + SEP.decode()
    + "\n"
    "  Welcome, brave pony, to the shadow realm of Equestria.\n"
    "  Princess Luna's corrupted firewall (Suricata 9.0.0-dev) guards\n"
    "  the Crystal Vault.  The Night Guard drops anypony who asks\n"
    "  too loudly for the flag.\n"
    "\n"
    "  Whisper the ancient passphrase to claim your cutie mark:\n"
    "> "
).encode()

NOPE_MSG = (
    "  The Night Guard narrows her eyes.\n"
    '  "That is NOT the passphrase, foal."\n'
    "  *YOUR PACKET HAS BEEN DROPPED INTO THE SHADOW REALM*\n"
).encode()


class FlagHandler(socketserver.StreamRequestHandler):
    timeout = 10  # seconds before readline() gives up

    def handle(self):
        self.wfile.write(BANNER)
        self.wfile.flush()

        try:
            raw = self.rfile.readline(256)
        except Exception:
            return
        if not raw:
            return

        line = raw.decode().strip()
        if line == "give_me_the_flag":
            self.wfile.write(
                f"  *The Crystal Vault swings open*\n"
                f"  Princess Luna smiles. \"Well played, little hacker.\"\n"
                f"  FLAG: {FLAG}\n".encode()
            )
        else:
            self.wfile.write(NOPE_MSG)
        self.wfile.flush()


socketserver.TCPServer.allow_reuse_address = True
with socketserver.ThreadingTCPServer((HOST, PORT), FlagHandler) as srv:
    srv.serve_forever()
