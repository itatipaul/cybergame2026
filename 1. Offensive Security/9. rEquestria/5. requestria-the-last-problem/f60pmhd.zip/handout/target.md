
Target server specification (178.105.103.127)

| | |
|---|---|
| OS | Ubuntu 24.04.3 LTS |
| Kernel | 6.8.0-90-generic |
| CPU | AMD EPYC-Genoa, 2 vCPUs @ 2.0 GHz |
| RAM | ~3.8 GiB |
| Disk | 75 GB (SSD) |
| Docker | 29.4.2 |

---
